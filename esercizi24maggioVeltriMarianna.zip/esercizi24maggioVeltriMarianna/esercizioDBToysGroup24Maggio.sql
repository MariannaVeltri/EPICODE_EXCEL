/*Verificare che i campi definiti come PK siano univoci.*/

select product.id_product
from product
group by product.id_product
having count(id_product)>1;

select sales.idsales
from sales
group by sales.idsales
having count(idsales)>1;


select region.id_region
from region
group by id_region
having count(id_region)>1;

/*esponi l'elenco dei soli prodotti venduti e per ognuno di essi il fatturato totale per anno*/

select p.product_name as nomeprodotto,
YEAR (s.sales_date) as anno,
sum(s.quantity*p.price) as FatturatoMedio
from product as p
left join sales as s on p.id_product = s.id_product
group by nomeprodotto, anno;

/*Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente. */

select sum(s.quantity*p.price) as fatturatoTotale,
r.name_region as Stato,
YEAR(s.sales_date) as anno
from sales as s
join product as p on p.id_product = s.id_product
join region as r on r.id_region = s.id_region
group by stato, anno 
order by anno, fatturatoTotale desc;


/*Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato? */

select p.category as categoriaprodotto
from product as p
join sales as s on p.id_product = s.id_product 
group by categoriaprodotto 
having sum(p.price*s.quantity) >= ( 
									select Max(FatturatoTotale) 
                                    from ( 
										select sum(p.price*s.quantity) as FatturatoTotale
										from product as p
										join sales as s on p.id_product = s.id_product
										group by p.category
                                         ) A
                                   );      


/*Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti. */

select product_name as nomeprodotto
from product 
where product_name not in (
							select distinct (p.product_name) as nomeprodotto
								from product as p
								join sales as s on p.id_product = s.id_product
                            );

/*Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).*/

select s.sales_date as DataVendita,
p.product_name as NomeProdotto
from sales as s
join product as p on s.id_product = p.id_product
group by DataVendita, NomeProdotto
order by DataVendita Desc;